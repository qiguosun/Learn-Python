print("Initial ecommerce")
